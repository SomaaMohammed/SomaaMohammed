import java.util.ArrayList;

public class WaitingList<T> {
	private ArrayList<T> list;

	public WaitingList() {
		list = new ArrayList<>();
	}

	public void add(T t) {
		list.add(t);
	}

	public T get(int search) {
		if (list.size() -1 <= search)
			return list.get(search);
		else
			return null;
	}

	public void reverse() {

		int i = 0;
		int j = list.size() - 1;

		while (i < j) {

			T temp = list.get(i);
			list.set(i, list.get(j));
			list.set(j, temp);
			i++;
			j--;
			
		}
	}
}
