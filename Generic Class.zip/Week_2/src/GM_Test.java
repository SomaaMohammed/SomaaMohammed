
public class GM_Test {
	public static void main(String[] args) {
		Student[] students = new Student[3];
		Car[] cars = new Car[4];

		Student s1 = new Student(1, "Ahmad", 4.0);
		Student s2 = new Student(2, "Mohammad", 3.4);
		Student s3 = new Student(3, "Ismail", 2.7);

		students[0] = s1;
		students[1] = s2;
		students[2] = s3;

		Car c1 = new Car(123456, "BMW");
		Car c2 = new Car(123457, "Mercedes");
		Car c3 = new Car(123458, "Volvo");
		Car c4 = new Car(123459, "Hyundai");

		cars[0] = c1;
		cars[1] = c2;
		cars[2] = c3;
		cars[3] = c4;

		swapFirstLast(students);
		swapFirstLast(cars);

		reverse(students);
		reverse(cars);

		shift(students);
		shift(students);

		print(students);
		print(cars);

	}

	public static <T> void swapFirstLast(T[] array) {
		T replace = array[array.length - 1];

		array[array.length - 1] = array[0];
		array[0] = replace;
	}

	public static <T> void reverse(T[] array) {
		T[] newarray = (T[]) new Object[array.length];
		int counter = 0;

		for (int i = array.length - 1; i >= 0; i--, counter++) {
			newarray[counter] = array[i];
		}

		array = newarray;
	}

	public static <T> void shift(T[] array) {
		T temp = array[0];

		for (int i = 0; i <= array.length - 2; i++) {

			array[i] = array[i + 1];
		}

		array[array.length - 1] = temp;
	}

	public static <T> void print(T[] array) {
		for (T element : array)
			System.out.println(element);
	}
}
