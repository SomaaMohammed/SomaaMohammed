
public class Test {
	public static void main(String[] args) {
		MyList<Integer> list1 = new  MyList<>(3);
		
		list1.add(44);
		list1.add(5);
		list1.add(7);
		list1.add(9);
		
		list1.display();
		
		try {
			System.out.println(list1.get(3));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
