
public class MyList<T> {
	private T[] elements;
	private int count;

	public MyList() {
		this(10);
	}

	public MyList(int s) {
		elements = (T[]) new Object[s];
		count = 0;
	}

	public void add(T t) {
		if (count < elements.length) {
			elements[count++] = t;
		} else {
			int counter = 0;
			T[] tmp = (T[]) new Object[elements.length * 2];
			for (T t2 : elements) {
				tmp[counter] = t2;
				counter++;
			}
			elements = tmp;
			elements[count++] = t;
		}
	}

	public int size() {
		return count;
	}

	public boolean isEmpty() {
		return count == 0;
	}

	public void clear() {
		for (int i = 0; i < count; i++) {
			elements[i] = null;
		}
		count = 0;
	}

	public T get(int search) throws Exception {
		if (search < 0 || search > count) {
			throw new Exception("Out of bounds");
		} else {
			return elements[search];
		}
	}

	public void display() {
		for (int i = 0; i < count; i++) {
			System.out.println(elements[i]);
		}
	}

	public void set(int search, T element) throws Exception {
		if (search < 0 || search > count) {
			throw new Exception("Out of bounds");
		} else {
			elements[search] = element;
		}
	}

	public boolean contains(T t) {

		for (int i = 0; i < count; i++)
			if (elements[i].equals(t))
				return true;

		return false;
	}

	public int indexOf(T t) {
		for (int i = 0; i < count; i++)
			if (elements[i].equals(t))
				return i;

		return -1;
	}

	public T[] toArray() {
		T[] tmp = (T[]) new Object[count];
		int counter = 0;

		for (T t : elements) {
			tmp[counter++] = t;
		}

		return tmp;
	}

	public T remove(int search) throws Exception {
		if (search < 0 || search > count) {
			throw new Exception("Out of bounds");
		} else {
			T tmp = elements[search];
			for (int i = search; i < count; i++) {
				elements[i] = elements[i + 1];
			}
			elements[count - 1] = null;
			count--;
			return tmp;
		}
	}
	
	
}
