package shipment;

public enum PaymentPlan {
	Postponed,Partial,PaidTotal
}
