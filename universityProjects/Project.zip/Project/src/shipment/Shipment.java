package shipment;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Arrays;

import client.Client;
import destination.Destination;
import payment.Payment;
import shipmentStatus.ShippingWays;

public class Shipment implements Serializable {
	private String shipmentCode;
	private LocalDate registrationDate;
	private double weight;
	private double shippingCost;
	private Client shipper;
	private Destination destination;
	private ShippingWays shippingWay;
	private Payment[] paymentWay;
	private double amountPaid;
	private PaymentPlan paymentPlan;

	public Shipment(String shipmentCode, LocalDate registrationDate, double weight, double shippingCost, Client shipper,
			Destination destination, ShippingWays shippingWay, Payment[] paymentWay) {
		setShipmentCode(shipmentCode);
		setRegistrationDate(registrationDate);
		setWeight(weight);
		setShippingCost(shippingCost);
		setShipper(shipper);
		setDestination(destination);
		setShippingWay(shippingWay);
		setPaymentWay(paymentWay);
	}

	public String getShipmentCode() {
		return shipmentCode;
	}

	public void setShipmentCode(String shipmentCode) {
		this.shipmentCode = shipmentCode;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getShippingCost() {
		return shippingCost;
	}

	public void setShippingCost(double shippingCost) {
		this.shippingCost = shippingCost;
	}

	public Client getShipper() {
		return shipper;
	}

	public void setShipper(Client shipper) {
		this.shipper = shipper;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public ShippingWays getShippingWay() {
		return shippingWay;
	}

	public void setShippingWay(ShippingWays shippingWay) {
		this.shippingWay = shippingWay;
	}

	public Payment[] getPaymentWay() {
		return paymentWay;
	}

	public void setPaymentWay(Payment[] paymentWay) {
		this.paymentWay = paymentWay;
	}
	public PaymentPlan getPaymentPlan() {
		return paymentPlan;
	}

	public void setPaymentPlan(PaymentPlan paymentPlan) {
		this.paymentPlan = paymentPlan;
	}

	public void addPayment(Payment payment) {
		// Check if paymentWays is null for safety
		if (paymentWay == null) {
			paymentWay = new Payment[1]; // Initialize with size 1
			paymentWay[0] = payment;
		} else {
			// Create a new array with one extra element
			Payment[] newArray = new Payment[paymentWay.length + 1];
			System.arraycopy(paymentWay, 0, newArray, 0, paymentWay.length);
			newArray[newArray.length - 1] = payment;
			paymentWay = newArray;
		}
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	@Override
	public String toString() {
		return "Shipment Code: " + shipmentCode + "\n" + destination + "\nShipper: " + shipper
				+ "\nRegistration Date: " + registrationDate + ", Weight: " + weight + "\nShipping Cost: "
				+ shippingCost + ", Amount Paid: " + amountPaid + ", Shipping method: " + shippingWay
				+ "\nPayments: " + Arrays.toString(paymentWay) + ", Payment Plan: " + paymentPlan+ ", Amount due: " +(shippingCost-amountPaid);
	}

}
