package payment;

import java.io.Serializable;
// Interface cannot "implement" another interface
// Use "extends" for an interface to inherit another interface
public interface Payment extends Serializable {

	abstract double calcPaymentAmount();
}
