package shipmentStatus;

public enum ShippingWays {
	GroundShipping, SeaFreight, AirFreight

}
