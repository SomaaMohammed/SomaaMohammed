package shipmentStatus;

import java.io.Serializable;
import java.time.LocalDate;

import shipment.Shipment;

public class ShipmentStatus implements Serializable {
	private LocalDate shippingDate;
	private LocalDate receivingDate;
	private Shipment shipment;

	public ShipmentStatus(Shipment shipment, LocalDate shippingDate, LocalDate receivingDate) {
		super();
		this.shipment = shipment;
		this.shippingDate = shippingDate;
		this.receivingDate = receivingDate;

	}

	public LocalDate getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(LocalDate shippingDate) {
		this.shippingDate = shippingDate;
	}

	public LocalDate getReceivingDate() {
		return receivingDate;
	}

	public void setReceivingDate(LocalDate receivingDate) {
		this.receivingDate = receivingDate;
	}

	public Shipment getShipment() {
		return shipment;
	}

	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}

	@Override
	public String toString() {
		return "Shipping date: " + shippingDate + ", Receiving date: " + receivingDate + "\n"
				+ shipment;
	}

}
