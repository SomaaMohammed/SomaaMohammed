package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import client.*;
import destination.*;
import payment.*;
import shipment.*;
import shipmentStatus.*;

public class TestApp {
	private static ArrayList<Client> clients = new ArrayList<>();
	private static ArrayList<Shipment> shipments = new ArrayList<>();
	private static ArrayList<Destination> destinations = new ArrayList<>();
	private static ArrayList<ShipmentStatus> shipmentsStatus = new ArrayList<>();
	private static int id = 1001;
	private static int destinationCode = 1001;
	private static int shipmentcode = 1001;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		File fileCheck = new File("dataProject.dat");
		if (fileCheck.exists()) {
			System.out.println("Data being loaded...");
			load();
		} else {
			System.out.println("No saved data to load");
		}
		int choice;
		printMenu(); // To output the menu
		do {

			while (!scanner.hasNextInt()) {
				System.out.println("Invalid input. Please enter a valid number: ");
				scanner.next(); // Discard the invalid input to avoid an infinite loop
			}

			// Read the integer choice from the user
			choice = scanner.nextInt();

			if (choice < 1 || choice > 13) {
				System.out.println("Invalid input. Please enter a number between 1 and 13.");
				continue; // Skip to the next iteration of the loop if input is not in the correct range
			}

			if (choice == 1) {
				addClient();
				System.out.println("Client added successfully.\n");
				printMenu();
			} else if (choice == 2) {
				addDestination();
				printMenu();
			} else if (choice == 3) {
				createNewShipment();
				printMenu();
			} else if (choice == 4) {
				updateExistingShipment();
				printMenu();
			} else if (choice == 5) {
				sendRecieveShipment();
				printMenu();
			} else if (choice == 6) {
				report1();
				printMenu();
			} else if (choice == 7) {
				report2();
				printMenu();
			} else if (choice == 8) {
				report3();
				printMenu();
			} else if (choice == 9) {
				report4();
				printMenu();
			} else if (choice == 10) {
				report5();
				printMenu();
			} else if (choice == 11) {
				report6();
				printMenu();
			} else if (choice == 12) {
				report7();
				printMenu();
			} else if (choice == 13) {
				save();
				break;
			}

		} while (choice != 13); // Continue looping until the user chooses to exit

		scanner.close();
	}

	public static void addClient() {
		Client client = null;
		Scanner in = new Scanner(System.in);
		boolean validInput = false;

		while (!validInput) { // Loop until valid input is received
			System.out.println("What type of client? \n1. Client \n2. Student \n3. Company \n4. Staff");
			int input = in.nextInt(); // Read the user's choice as an integer
			in.nextLine(); // Consume newline

			if (input < 1 || input > 4) {
				System.out.println("Please enter a valid number from 1-4.\n1");
			} else {
				validInput = true; // Set validInput to true to exit the loop
				if (input == 1) {
					System.out.println("Please enter client name: ");
					String clientName = in.nextLine();
					client = new Client(id, clientName);
					clients.add(client);

				} else if (input == 2) {
					System.out.println("Please enter student name: ");
					String clientName = in.nextLine();

					System.out.println("Please enter university id: ");
					while (!in.hasNextInt()) { // Check if the next input is an integer
						System.out.println("Invalid input. Please enter a valid integer for university id.");
						in.nextLine(); // Consume the incorrect input
					}
					int uni_id = in.nextInt();
					in.nextLine();

					System.out.println("Please enter university name: ");
					String uni_name = in.nextLine();
					client = new Student(id, clientName, uni_id, uni_name);
					clients.add(client);
				} else if (input == 3) {
					System.out.println("Please enter company name: ");
					String clientName = in.nextLine();
					System.out.println("Please enter company location: ");
					String location = in.nextLine();
					System.out.println("Please enter company poBox: ");
					while (!in.hasNextInt()) { // Check if the next input is an integer
						System.out.println("Invalid input. Please enter a valid integer for company poBox.");
						in.nextLine(); // Consume the incorrect input
					}
					int poBox = in.nextInt(); // Read the poBox number
					in.nextLine(); // Consume newline

					client = new Company(id, clientName, location, poBox);
					clients.add(client);

				} else if (input == 4) {
					System.out.println("Please enter staff name: ");
					String clientName = in.nextLine();
					System.out.println("Please enter job id: ");
					String jobid = in.nextLine();
					client = new Staff(id, clientName, jobid);
					clients.add(client);
				}

			}
		}
		id++; // Increment the ID for the next client
	}

	public static void addDestination() {
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter the destination name: ");
		String desname = in.nextLine();

		System.out.println("Please enter the air 1st kilo cost: ");
		double air1stkilocost;
		while (true) {
			if (in.hasNextDouble()) {
				air1stkilocost = in.nextDouble();
				if (air1stkilocost >= 0) {
					break;
				} else {
					System.out.println("Invalid input. The cost cannot be negative.");
				}
			} else {
				System.out.println("Invalid input. Please enter a valid number.");
			}
			in.nextLine(); // Clear the invalid input
		}
		in.nextLine(); // Consume any leftover newline

		System.out.println("Please enter the air cost each add half: ");
		double airCostEachAddHalf;
		while (true) {
			if (in.hasNextDouble()) {
				airCostEachAddHalf = in.nextDouble();
				if (airCostEachAddHalf >= 0) {
					break;
				} else {
					System.out.println("Invalid input. The cost cannot be negative.");
				}
			} else {
				System.out.println("Invalid input. Please enter a valid number.");
			}
			in.nextLine(); // Clear the invalid input
		}
		in.nextLine(); // Consume any leftover newline

		System.out.println("Please enter the ground shipping discount (in %): ");
		double groundShippingDiscount;
		while (true) {
			if (in.hasNextDouble()) {
				groundShippingDiscount = in.nextDouble();
				if (groundShippingDiscount >= 0 && groundShippingDiscount <= 100) {
					groundShippingDiscount /= 100; // Convert percentage to a decimal
					break;
				} else {
					System.out.println("Invalid input. The discount must be between 0 and 100.");
				}
			} else {
				System.out.println("Invalid input. Please enter a valid number.");
			}
			in.nextLine(); // Clear the invalid input
		}
		in.nextLine(); // Consume any leftover newline

		System.out.println("Please enter the sea shipping discount (in %): ");
		double seaShippingDiscount;
		while (true) {
			if (in.hasNextDouble()) {
				seaShippingDiscount = in.nextDouble();
				if (seaShippingDiscount >= 0 && seaShippingDiscount <= 100) {
					seaShippingDiscount /= 100; // Convert percentage to a decimal
					break;
				} else {
					System.out.println("Invalid input. The discount must be between 0 and 100.");
				}
			} else {
				System.out.println("Invalid input. Please enter a valid number.");
			}
			in.nextLine(); // Clear the invalid input
		}
		in.nextLine(); // Consume any leftover newline

		Destination destination = new Destination("Des" + destinationCode, desname, air1stkilocost, airCostEachAddHalf,
				groundShippingDiscount, seaShippingDiscount);
		destinationCode++; // Increment the destination code for future destinations
		destinations.add(destination);
		System.out.println("Destination added successfully.\n");
	}

	public static void createNewShipment() {
		if (clients.size() == 0 || destinations.size() == 0) {
			System.out.println("Error! Please add a Client/Destination first.\n");
			return;
		}
		Shipment shipment;
		Scanner in = new Scanner(System.in);

//		QUESTION 5-D START 

		System.out.println("Please enter the weight of the shipment: ");
		double weight = in.nextDouble();
		double weightnew = 0;
		if (weight <= 1)
			weightnew = 1;
		else if (weight > 1)
			weightnew = roundToNearestHalf(weight);

//		QUESTION 5-D END 

//		QUESTION 5-E START		

		System.out.println("Please choose the shipper: ");
		for (int i = 1; i < clients.size() + 1; i++) {
			System.out.println(i + ": " + clients.get(i - 1).getName()); // looping through clients ArrayList displaying
																			// all clients
		}
		int finalChoice = 0;
		while (true) { // while loop to validate input number is within range
			int input = in.nextInt();
			if (1 > input || input > clients.size())
				System.out.println("Invalid input. Please enter a valid number: ");
			else if (input > 0 && input < clients.size() + 1) {
				finalChoice = input;
				break;
			}
		}
		Client shipper = clients.get(finalChoice - 1);

		System.out.println("Please choose the destination: "); // doing the same thing for destinations
		for (int i = 1; i < destinations.size() + 1; i++) {
			System.out.println(i + ": " + destinations.get(i - 1).getDestName());
		}
		while (true) {
			int input = in.nextInt();
			if (1 > input || input > destinations.size())
				System.out.println("Invalid input. Please enter a valid number: ");
			else if (input > 0 && input < destinations.size() + 1) {
				finalChoice = input;
				break;
			}
		}

		Destination destination = destinations.get(finalChoice - 1);
//		QUESTION 5-E END 

//		SHIPPING COST CALCULATION - QUESTION 5-D-C START
		double shippingCost;
		if (shipper instanceof Staff) {		// for staff discount
			if (weightnew > 1)
				shippingCost = (destination.getAirCost1stKilo()
						+ (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
						- ((destination.getAirCost1stKilo() + (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
								* ((Staff) shipper).getDISCOUNT());
			else
				shippingCost = (destination.getAirCost1stKilo())
						- (destination.getAirCost1stKilo() * ((Staff) shipper).getDISCOUNT());
		} else if (shipper instanceof Student) {			//for student discount
			if (weightnew > 1)
				shippingCost = (destination.getAirCost1stKilo()
						+ (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
						- ((destination.getAirCost1stKilo() + (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
								* ((Student) shipper).getDISCOUNT());
			else
				shippingCost = (destination.getAirCost1stKilo())
						- (destination.getAirCost1stKilo() * ((Student) shipper).getDISCOUNT());
		} else if (shipper instanceof Company) {			// for company discount
			if (weightnew > 1)
				shippingCost = (destination.getAirCost1stKilo()
						+ (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
						- ((destination.getAirCost1stKilo() + (weightnew - 1) * 2 * destination.getAirCostEachAddHalf())
								* ((Company) shipper).getDISCOUNT());
			else
				shippingCost = (destination.getAirCost1stKilo())
						- (destination.getAirCost1stKilo() * ((Company) shipper).getDISCOUNT());
		} else {
			if (weightnew > 1)
				shippingCost = destination.getAirCost1stKilo()
						+ (weightnew - 1) * 2 * destination.getAirCostEachAddHalf();
			else
				shippingCost = destination.getAirCost1stKilo();
		}
//		SHIPPING COST CALCULATION - QUESTION 5-D-C END

//		QUESTION 5-F START 
		ShippingWays shippingWay = ShippingWays.AirFreight;
		String finalAnswer;

		System.out.println("Current shipping way: Air Freight. Would you like to change the shipping way? (yes/no)");
		while (true) {
			String input = in.next();
			if (input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("no")) {
				finalAnswer = input;
				break;
			} else
				System.out.println("Invalid input, please input \"yes\" or \"no\"");
		}

		if (finalAnswer.equalsIgnoreCase("yes")) {
			System.out.println("What shipping way would you like? \n1- Ground Shipping\n2- Sea Freight");
			while (true) {
				int input = in.nextInt();
				if (1 > input || input > 2)
					System.out.println("Invalid input. Please enter a valid number: ");
				else if (input > 0 && input < 3) {
					finalChoice = input;
					break;
				}
			}

			if (finalChoice == 1) {
				shippingWay = ShippingWays.GroundShipping;
				shippingCost = shippingCost - (shippingCost * destination.getGroundShippingDiscount());
			} else {
				shippingWay = ShippingWays.SeaFreight;
				shippingCost = shippingCost - (shippingCost * destination.getSeaShippingDiscount());
			}

		}
//		QUESTION 5-F END 

//		QUESTION 5-G START
		System.out.println(
				"What payment plan would you like to follow? \n1- Postponed till later \n2- Paid in partial \n3- Paid in total");

		while (true) {
			int input = in.nextInt();
			if (1 > input || input > 3)
				System.out.println("Invalid input. Please enter a valid number: ");
			else if (input > 0 && input < 4) {
				finalChoice = input;
				break;
			}
		}
		PaymentPlan paymentPlan = null;
		if (finalChoice == 1)
			paymentPlan = PaymentPlan.Postponed;
		else if (finalChoice == 2)
			paymentPlan = PaymentPlan.Partial;
		else if (finalChoice == 3)
			paymentPlan = PaymentPlan.PaidTotal;
//		QUESTION 5-G END 

		shipment = new Shipment("Ship" + shipmentcode, LocalDate.now(), weight, shippingCost, shipper, destination,
				shippingWay, null);
		shipment.setPaymentPlan(paymentPlan);

//		checking amount paid
		if (paymentPlan == PaymentPlan.PaidTotal) { // If payment is paid in full
			System.out.printf(
					"Amount due: %.2f \nWhat payment way would you like to use? \n1- Credit Card Payment \n2- Wire Transfer Payment \n3- Check Payment \n4- Cash Payment\n",
					shippingCost);

			while (true) {
				int input = in.nextInt();
				if (1 > input || input > 4)
					System.out.println("Invalid input. Please enter a valid number: ");
				else if (input > 0 && input < 5) {
					finalChoice = input;
					break;
				}
			}
			Payment payment;
			if (finalChoice == 1) {
				payment = new CreditCard(shippingCost);
				shipment.addPayment(payment);
			} else if (finalChoice == 2) {
				payment = new WireTransfer(shippingCost);
				shipment.addPayment(payment);
			} else if (finalChoice == 3) {
				payment = new Check(shippingCost);
				shipment.addPayment(payment);
			} else if (finalChoice == 4) {
				payment = new Cash(shippingCost);
				shipment.addPayment(payment);
			}

			shipment.setAmountPaid(shippingCost);

		}
		if (paymentPlan == PaymentPlan.Partial) { // If payment is paid in partial
			double amountLeft = shipment.getShippingCost() - shipment.getAmountPaid();
			System.out.printf("How much would you like to pay? Amount left: %.2f\n", amountLeft);
			double partialPaymentAmount;
			while (true) {
				double input = in.nextDouble();
				if (0 >= input || input > amountLeft)
					System.out.println("Invalid input. Please enter a valid number: ");
				else if (input > 0 && input <= amountLeft) {
					partialPaymentAmount = input;
					break;
				}
			}

			System.out.printf(
					"Amount due: %.2f \nWhat payment way would you like to use? \n1- Credit Card Payment \n2- Wire Transfer Payment \n3- Check Payment \n4- Cash Payment\n",
					partialPaymentAmount);

			while (true) {
				int input = in.nextInt();
				if (1 > input || input > 4)
					System.out.println("Invalid input. Please enter a valid number: ");
				else if (input > 0 && input < 5) {
					finalChoice = input;
					break;
				}
			}
			Payment payment;
			if (finalChoice == 1) {
				payment = new CreditCard(partialPaymentAmount);
				shipment.addPayment(payment);
			} else if (finalChoice == 2) {
				payment = new WireTransfer(partialPaymentAmount);
				shipment.addPayment(payment);
			} else if (finalChoice == 3) {
				payment = new Check(partialPaymentAmount);
				shipment.addPayment(payment);
			} else if (finalChoice == 4) {
				payment = new Cash(partialPaymentAmount);
				shipment.addPayment(payment);
			}

			shipment.setAmountPaid(shipment.getAmountPaid() + partialPaymentAmount);
		}

//		QUESTION 5-H START 
		shipments.add(shipment);
		System.out.println("Shipment created successfully.\n");
		shipmentcode++;
//		QUESTION 5-H END 

//		QUESTION 5-I START 
		if (shipment.getAmountPaid() == shipment.getShippingCost()) {
			ShipmentStatus shipmentStatus = new ShipmentStatus(shipment, null, null);
			shipmentsStatus.add(shipmentStatus);
		}
//		QUESTION 5-I END 
	}

	public static void updateExistingShipment() {
		if (shipments.size() == 0) {
			System.out.println("There are no current shipments.\n");
			return;
		}
		Scanner in = new Scanner(System.in);
		System.out.println("Please select the shipment by entering the shipment code: \n---------------------------------------------------------");
		for (Shipment s : shipments) { // displaying all shipments in the shipments ArrayList
			System.out.printf("%s - Shipper: %s, Destination: %s\n", s.getShipmentCode(), s.getShipper().getName(),
					s.getDestination().getDestName());
		}
		Shipment shipment = null;
		String choice = null;
		boolean found = false;
		while (true) {
			choice = in.next();
			for (Shipment s : shipments) { // checking if the code input is a valid shipment code
				if (s.getShipmentCode().equalsIgnoreCase(choice)) {
					found = true;
					shipment = s;
				}
			}
			if (found) // if found = it continues, if not found = it asks again
				break;
			System.out.println("Error! Invalid shipment code. Please try again: ");
		}

		double amountLeft = shipment.getShippingCost() - shipment.getAmountPaid(); // amount left to pay

		if (amountLeft == 0)
			System.out.println("Shipment has been paid fully. No more modifications allowed.\n");
		else {
			if (amountLeft == shipment.getShippingCost()) { // i.e no payment has been made
				System.out.printf(
						"Current shipping way: %s. Current shipping cost: %.2f \nWould you like to change the shipping way? (yes/no)\n",
						shipment.getShippingWay().toString(), shipment.getShippingCost());
				while (true) {
					String input = in.next(); // reused code, validation for yes/no input
					if (input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("no")) {
						choice = input;
						break;
					} else
						System.out.println("Invalid input, please input \"yes\" or \"no\"");
				}

				if (choice.equalsIgnoreCase("yes")) {
					System.out.println(
							"What shipping way would you like? \n1- Air Freight\n2- Ground Shipping\n3- Sea Freight");
					int intChoice = 0;
					while (true) {
						int input = in.nextInt();
						if (1 > input || input > 3)
							System.out.println("Invalid input. Please enter a valid number from 1-3: ");
						else if (input > 0 && input < 4) {
							intChoice = input;
							break;
						}
					}
					double originalAmount = 0; // getting original cost since there was sea/ground discounts
					if (shipment.getShippingWay() == ShippingWays.GroundShipping)
						originalAmount = shipment.getShippingCost()
								/ (1 - shipment.getDestination().getGroundShippingDiscount()); // ex: 850 / (1 - 0.15) =
																								// 1000
					else if (shipment.getShippingWay() == ShippingWays.SeaFreight)
						originalAmount = shipment.getShippingCost()
								/ (1 - shipment.getDestination().getSeaShippingDiscount());
					else if (shipment.getShippingWay() == ShippingWays.AirFreight)
						originalAmount = shipment.getShippingCost();

					if (intChoice == 1) { // resetting the new shipping cost with updated discounts
						shipment.setShippingWay(ShippingWays.AirFreight);
						shipment.setShippingCost(originalAmount);
					} else if (intChoice == 2) {
						shipment.setShippingWay(ShippingWays.GroundShipping);
						shipment.setShippingCost(originalAmount
								- (originalAmount * shipment.getDestination().getGroundShippingDiscount()));
					} else if (intChoice == 3) {
						shipment.setShippingWay(ShippingWays.SeaFreight);
						shipment.setShippingCost(
								originalAmount - (originalAmount * shipment.getDestination().getSeaShippingDiscount()));
					}

					System.out.printf("Shipping way successfully updated. New shipping cost: %.2f\n",
							shipment.getShippingCost());
				}
			} else {
				System.out.println("There has been a payment already, shipping way can not be modified.");
			}
			amountLeft = shipment.getShippingCost() - shipment.getAmountPaid();
			System.out.printf("Amount due: %.2f. Would you like to make a payment? (yes/no)\n", amountLeft);

			while (true) { // reused code, validation for yes/no input
				String input = in.next();
				if (input.equalsIgnoreCase("yes") || input.equalsIgnoreCase("no")) {
					choice = input;
					break;
				} else
					System.out.println("Invalid input, please input \"yes\" or \"no\"");
			}

			if (choice.equalsIgnoreCase("yes")) {
				System.out.println("How much would you like to pay?");
				double paymentAmount;
				while (true) { // reused code, validation to check the number is no more than the total cost
					double input = in.nextDouble();
					if (0 >= input || input > amountLeft)
						System.out.println("Invalid input. Please enter a valid number within range: ");
					else if (input > 0 && input <= amountLeft) {
						paymentAmount = input;
						break;
					}
				}
				System.out.printf(
						"Amount due: %.2f \nWhat payment way would you like to use? \n1- Credit Card Payment \n2- Wire Transfer Payment \n3- Check Payment \n4- Cash Payment\n",
						paymentAmount);
				int intChoice = 0;
				while (true) {
					int input = in.nextInt();
					if (1 > input || input > 4)
						System.out.println("Invalid input. Please enter a valid number from 1-4: ");
					else if (input > 0 && input < 5) {
						intChoice = input;
						break;
					}
				}
				Payment payment; // choosing payment method and updating the shipment payments
				if (intChoice == 1) {
					shipment.addPayment(new CreditCard(paymentAmount));
				} else if (intChoice == 2) {
					shipment.addPayment(new WireTransfer(paymentAmount));
				} else if (intChoice == 3) {
					shipment.addPayment(new Check(paymentAmount));
				} else if (intChoice == 4) {
					shipment.addPayment(new Cash(paymentAmount));
				}

				shipment.setAmountPaid(shipment.getAmountPaid() + paymentAmount); // updating shipment amount paid
				System.out.println("Payment successful.\n");
				shipment.setPaymentPlan(PaymentPlan.Partial); // updating payment plan in case it was "postponed"

				if (shipment.getAmountPaid() == shipment.getShippingCost()) { // if total amount is paid = add to
																				// shipmentStatus ArrayList
					shipmentsStatus.add(new ShipmentStatus(shipment, null, null));
				}
			}

		}

	}

	public static void sendRecieveShipment() {
		if (shipments.size() == 0) {
			System.out.println("There are no current shipments.\n");
			return;
		}
		Scanner in = new Scanner(System.in); // reused code from question 6:
		System.out.println("Please select the shipment by entering the shipment code: \n---------------------------------------------------------");
		for (Shipment s : shipments) { // displaying all shipments in the shipments ArrayList
			System.out.printf("%s - Shipper: %s, Destination: %s\n", s.getShipmentCode(), s.getShipper().getName(),
					s.getDestination().getDestName());
		}
		Shipment shipment = null;
		String choice = null;
		boolean found = false;
		while (true) {
			choice = in.next();
			for (Shipment s : shipments) { // checking if the code input is a valid shipment code
				if (s.getShipmentCode().equalsIgnoreCase(choice)) {
					found = true;
					shipment = s;
				}
			}
			if (found) // if found = it continues, if not found = it asks again
				break;
			System.out.println("Error! Invalid shipment code. Please try again: ");
		}

		ShipmentStatus shipmentStatus = null; // getting the shipmentStatus
		for (ShipmentStatus s : shipmentsStatus)
			if (s.getShipment().equals(shipment))
				shipmentStatus = s;

		if (shipment.getShippingCost() - shipment.getAmountPaid() != 0) { // closing the method if there is still amount
																			// due
			System.out.println("Error! The shipment has not been fully paid for yet.\n");
			return;
		}
		while (true) {
			System.out.println("What would you like? \n1- Send the shipment \n2- Receive the shipment. \n3- Exit");

			int intChoice = 0; // reused code, validating user input
			while (true) {
				int input = in.nextInt();
				if (1 > input || input > 3)
					System.out.println("Invalid input. Please enter a valid number from 1-3: ");
				else if (input > 0 && input < 4) {
					intChoice = input;
					break;
				}
			}
			if (intChoice == 1) { // if sending the shipment.
				if (shipmentStatus.getShippingDate() != null) { // ending if it already has a shipping date
					System.out.println("Error! Shipment already has a shipping date.\n");
					break;
				}
				LocalDate sendingDate = null;
				System.out.println("Enter a sending date (format: yyyy-mm-dd):");
				while (sendingDate == null) {

					String input = in.next();

					try {
						sendingDate = LocalDate.parse(input); // parsing String into localDate
						if (sendingDate.isBefore(shipment.getRegistrationDate())) {
							System.out
									.println("Sending date must be the shipment's registration date or a future date.");
							System.out.println("Please enter a valid date: ");
							sendingDate = null; // reset sendingDate to null to continue the loop
						}
					} catch (Exception e) {
						System.out.println("Invalid date format. Please enter the date in the format: yyyy-mm-dd");
					}
				}

				shipmentStatus.setShippingDate(sendingDate);
				System.out.println("Sending date is set to: " + sendingDate + "\n");
				break;
			} else if (intChoice == 2) {
				if (shipmentStatus.getReceivingDate() != null) { // reused code as above, but with receiving
					System.out.println("Error! Shipment already has a receiving date.\n");
					break;
				}

				if (shipmentStatus.getShippingDate() == null) {
					System.out.println("Error! The shipment has not been sent yet. Please assign a shipping date.\n");
					return;
				}
				LocalDate receivingDate = null;
				System.out.println("Enter a receiving date (format: yyyy-mm-dd):");
				while (receivingDate == null) {

					String input = in.next();

					try {
						receivingDate = LocalDate.parse(input);
						if (receivingDate.isBefore(shipmentStatus.getShippingDate())
								|| receivingDate.isEqual(shipmentStatus.getShippingDate())) {
							System.out.println("Receiving date must be after the shipment's shipping date: "
									+ shipmentStatus.getShippingDate());
							System.out.println("Please enter a valid date: ");
							receivingDate = null;
						}
					} catch (Exception e) {
						System.out.println("Invalid date format. Please enter the date in the format: yyyy-mm-dd");
					}
				}

				shipmentStatus.setReceivingDate(receivingDate);
				System.out.println("Receiving date is set to: " + receivingDate + "\n");
				break;

			} else if (intChoice == 3)
				break;
		}
	}

	public static void report1() {
		if (clients.size() == 0) {
			System.out.println("Error! There are no current clients.\n");
			return;
		}

		// Initialize empty strings to add information for each client type
		String students = "";
		String companies = "";
		String staffs = "";
		String justClients = "";

		int studentCount = 0;
		int companyCount = 0;
		int staffCount = 0;
		int clientCount = 0;

		for (Client c : clients) {
			if (c instanceof Student) {
				studentCount++;
				Student s = (Student) c;
				students += s.getId() + "\t" + s.getName() + "\n";
			} else if (c instanceof Company) {
				companyCount++;
				Company company = (Company) c;
				companies += company.getId() + "\t" + company.getName() + "\n";
			} else if (c instanceof Staff) {
				staffCount++;
				Staff staff = (Staff) c;
				staffs += staff.getId() + "\t" + staff.getName() + "\n";
			} else {
				clientCount++;
				justClients += c.getId() + "\t" + c.getName() + "\n";
			}
		}

		// Print the report
		System.out.println(clientCount + " Client(s):\n" + justClients);
		System.out.println(studentCount + " Student(s):\n" + students);
		System.out.println(companyCount + " Company(s):\n" + companies);
		System.out.println(staffCount + " Staff(s):\n" + staffs);
	}

	public static void report2() {
		Scanner in = new Scanner(System.in);
		if (destinations.size() == 0) {
			System.out.println("Error! There are no current destinations.\n");
			return;
		}

		// List all available destinations with their codes and names
		System.out.println("All Destinations:\n-----------------");
		for (Destination d : destinations) {
			System.out.printf("%s - %s\n", d.getDestCode(), d.getDestName());
		}
		System.out.println("\nPlease enter the destination code you would like: ");
		Destination destination = null;
		String choice = null;
		boolean found = false;
		while (true) {
			choice = in.next();
			// Check each destination to see if the entered code matches any existing
			// destination's code
			for (Destination d : destinations) {
				if (d.getDestCode().equalsIgnoreCase(choice)) {
					found = true;
					destination = d; // Set the destination to the matched object
					break;
				}
			}
			if (found) // if found = it continues, if not found = it asks again
				break;
			System.out.println("Error! Invalid destination code. Please try again: ");
		}

		// Print the details of the selected destination.
		System.out.println(destination + "\n");
	}

	public static void report3() {
		if (shipments.size() == 0) {
			System.out.println("Error! There are no current shipments.\n");
			return;
		}
		Scanner in = new Scanner(System.in);
		System.out.println("All Shipments:\n--------------");
		for (Shipment s : shipments) {
			System.out.printf("%s - Shipper: %s, Destination: %s\n", s.getShipmentCode(), s.getShipper().getName(),
					s.getDestination().getDestName()); // reused code
		}
		System.out.println("\nPlease enter the shipping code you would like: ");
		Shipment shipment = null;
		String choice = null;
		boolean found = false;
		while (true) {
			choice = in.next();
			for (Shipment s : shipments) { // checking if the code input is a valid shipment code, also reused code
				if (s.getShipmentCode().equalsIgnoreCase(choice)) {
					found = true;
					shipment = s; // Assign the found shipment to the shipment variable
					break; // Exit the loop as soon as a match is found
				}
			}
			if (found) // if found = it continues, if not found = it asks again
				break;
			System.out.println("Error! Invalid shipment code. Please try again: ");
		}

		ShipmentStatus shipmentStatus = null; // getting the shipmentStatus
		for (ShipmentStatus s : shipmentsStatus)
			if (s.getShipment().equals(shipment))
				shipmentStatus = s; // Set shipmentStatus if a matching status is found

		if (shipmentStatus == null)
			// If no status is found, display a default status indicating it's not yet
			// tracked
			System.out.println(new ShipmentStatus(shipment, null, null) + "\n");
		else
			// If a status exists, display the detailed status of the shipment
			System.out.println(shipmentStatus + "\n");
	}

	public static void report4() {
		boolean found = false;
		for (ShipmentStatus s : shipmentsStatus)
			if (s.getShippingDate() == null)
				if (s.getShipment().getAmountPaid() == s.getShipment().getShippingCost()) {
					System.out.printf(
							"Shipment Code: %s%nShipping date: %s, Receiving date: %s%nClient name: %s, Client ID: %s%nDestination name: %s, Destination code: %s%nPayment way: %s%n----------------------------------------------------%n----------------------------------------------------%n",
							s.getShipment().getShipmentCode(), s.getShippingDate(), s.getReceivingDate(),
							s.getShipment().getShipper().getName(), s.getShipment().getShipper().getId(),
							s.getShipment().getDestination().getDestName(),
							s.getShipment().getDestination().getDestCode(), s.getShipment().getPaymentPlan());
					found = true;
				}
		if (!found)
			System.out.println("Error! There are currently no shipments queued.\n");

	}

	public static void report5() {
		if (shipments.size() == 0) {
			System.out.println("Error! There are no current shipments.\n");
			return;
		}
		Scanner in = new Scanner(System.in);

		System.out.println("To list your shipments, please enter your ID: ");
		for (Client c : clients) {
			System.out.println("Client name: " + c.getName() + ", Client ID: " + c.getId());
		}
		while (true) {
			int ID = 0;
			if (in.hasNextInt()) {
				ID = in.nextInt();
			} else {
				in.next(); // consume the invalid input
				System.out.println("Invalid input. Please enter a numeric ID:");
				continue;
			}

			boolean found = false;
			for (ShipmentStatus s : shipmentsStatus) {
				if (s.getShipment().getShipper().getId() == ID) {
					found = true;
					System.out.printf(
							"%s - Registration date: %s, Weight: %.1f, Cost: %.2f, Destination Name: %s, Sending date: %s, Receiving date: %s\n",
							s.getShipment().getShipmentCode(), s.getShipment().getRegistrationDate(),
							s.getShipment().getWeight(), s.getShipment().getShippingCost(),
							s.getShipment().getDestination().getDestName(), s.getShippingDate(), s.getReceivingDate());
				}
			}
			if (found) {
				break;
			} else {
				System.out.println("Error! No shipments found for this ID. Please try again:");
			}
		}
		System.out.println();

	}

	public static void report6() {
		double totalIncome = 0;
		for (Shipment s : shipments) {
			totalIncome += s.getAmountPaid();
		}
		System.out.printf("The company overall income is: QAR%.2f\n\n", totalIncome);
	}

	public static void report7() {
		if (shipments.size() == 0) {
			System.out.println("Error! There are no current shipments.\n");
			return;
		}
		boolean found = false;
		for (ShipmentStatus s : shipmentsStatus) {
			if (s.getReceivingDate() == null && s.getShippingDate() != null) {
				found = true;
				System.out.printf(
						"Shipment Code: %s%nShipping date: %s, Receiving date: %s%nClient name: %s, Client ID: %s%nDestination name: %s, Destination code: %s%nPayment way: %s%n----------------------------------------------------%n----------------------------------------------------%n",
						s.getShipment().getShipmentCode(), s.getShippingDate(), s.getReceivingDate(),
						s.getShipment().getShipper().getName(), s.getShipment().getShipper().getId(),
						s.getShipment().getDestination().getDestName(),
						s.getShipment().getDestination().getDestCode(), s.getShipment().getPaymentPlan());

			}
		}
		if(!found)
			System.out.println("Error! There are no current shipments not yet collected.\n");
	}

	public static double roundToNearestHalf(double number) {
		double rounded = Math.ceil(number * 2) / 2;
		return rounded;
	}

	public static void printMenu() {
		System.out.println("Please select one of the following:\n" + "1. Add client\n" + "2. Add destination\n"
				+ "3. Create new shipment\n" + "4. Update existing shipment\n" + "5. Sending/Receiving shipment\n"
				+ "6. Report1 - List the existing clients\n" + "7. Report2 - List the destination details\n"
				+ "8. Report3 - List the shipment details\n" + "9. Report4 - List the queued shipments\n"
				+ "10. Report5 - List the client shipments\n" + "11. Report6 - List the income\n"
				+ "12. Report7 - List the shipments not yet collected\n" + "13. Save and Exit\n");
	}

	public static void save() { // Method to save data to the file "dataProject.dat"
		try {
			FileOutputStream f = new FileOutputStream("dataProject.dat");
			ObjectOutputStream out = new ObjectOutputStream(f);
			// For the next 4 lines, "clients", "shipments", "destinations", and
			// "shipmentStatus"
			// are all ArrayLists and are saved as 1 object. Which is the ArrayList
			out.writeObject(clients);
			out.writeObject(shipments);
			out.writeObject(destinations);
			out.writeObject(shipmentsStatus);
			out.close();
			f.close();
			System.out.println("Save successful. ");
		} catch (Exception e) {
			System.out.println("Error saving data. " + e);
		}
	}

	public static void load() {
		File file = new File("dataProject.dat");
		if (!file.exists()) {
			System.out.println("File dataProject.dat not found. Program will terminate.");
			System.exit(0); // Exits the program. Status 0 indicates the termination is successful
		}
		try {
			FileInputStream f = new FileInputStream("dataProject.dat");
			ObjectInputStream in = new ObjectInputStream(f);
			clients = (ArrayList<Client>) in.readObject(); // Casts the object to an ArrayList of Client
			shipments = (ArrayList<Shipment>) in.readObject();
			destinations = (ArrayList<Destination>) in.readObject();
			shipmentsStatus = (ArrayList<ShipmentStatus>) in.readObject();
			in.close();
			f.close();
			int shipmentsSize = shipments.size(); // Updating the shipment code
			shipmentcode += shipmentsSize;
			int destinationsSize = destinations.size(); // Updating the destination code
			destinationCode += destinationsSize;
			int clientSize = clients.size(); // Updating the id
			id += clientSize;
			if (shipmentsSize == 0 && destinationsSize == 0 && clientSize == 0) {
				System.out.println("File is empty. Data not loaded.");
			} else {
				System.out.println("Loaded data successfully.");
			}

		} catch (Exception e) {
			System.out.println("Error loading data. " + e);

		}
	}

}